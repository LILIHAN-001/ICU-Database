# mimic-iv-code
Code and discussion around the MIMIC-IV database
