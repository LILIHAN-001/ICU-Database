---
title: "ICU"
linkTitle: "ICU"
date: 2020-08-10
weight: 30
description: >
  The ICU module contains information collected from the clinical information system used within the ICU. Documented data includes intravenous administrations, ventilator settings, and other charted items.
---