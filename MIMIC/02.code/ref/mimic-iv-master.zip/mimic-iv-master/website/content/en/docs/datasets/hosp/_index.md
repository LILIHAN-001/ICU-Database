---
title: "Hosp"
linkTitle: "Hosp"
date: 2020-08-10
weight: 20
description: >
  The Hosp module provides all data acquired from the hospital wide electronic health record. Information covered includes laboratory measurements, microbiology, medication administration, and billed diagnoses.
---