---
title: "Note"
linkTitle: "Note"
date: 2020-08-10
weight: 80
description: >
  The Note module provides free-text notes acquired from either the hospital wide electronic health record or the ICU information system.
---