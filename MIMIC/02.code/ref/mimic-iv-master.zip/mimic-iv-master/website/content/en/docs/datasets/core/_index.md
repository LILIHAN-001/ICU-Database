---
title: "Core"
linkTitle: "Core"
date: 2020-08-10
weight: 10
description: >
  The core module contains patient tracking data. Demographics, hospital admissions, and in-hospital ward transfers are described here.
---