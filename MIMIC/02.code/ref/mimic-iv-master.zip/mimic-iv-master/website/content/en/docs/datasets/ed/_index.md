---
title: "ED"
linkTitle: "ED"
date: 2020-08-10
weight: 40
description: >
  The ED module contains data for emergency department patients collected while they are in the ED. Information includes reason for admission, triage assessment, vital signs, and medicine reconciliaton.
---

{{% pageinfo %}}
MIMIC-ED is currently not publicly available and the structure is subject to change.
{{% /pageinfo %}}