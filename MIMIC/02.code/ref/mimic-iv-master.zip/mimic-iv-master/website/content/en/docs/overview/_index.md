---
title: "Overview"
linkTitle: "Overview"
weight: 1
description: >
  Introduction to MIMIC-IV including what the dataset is and what's changed since MIMIC-III.
---
