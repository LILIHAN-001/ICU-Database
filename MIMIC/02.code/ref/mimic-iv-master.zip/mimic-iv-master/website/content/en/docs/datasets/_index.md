---
title: "Data"
linkTitle: "Data"
weight: 3
date: 2020-08-10
description: >
  Description of the data contained in MIMIC-IV.
---
