`hadm_id` is an integer identifier which is unique for each patient hospitalization.
