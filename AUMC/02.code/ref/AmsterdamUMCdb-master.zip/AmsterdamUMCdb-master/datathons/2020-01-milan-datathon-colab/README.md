<img src="https://github.com/AmsterdamUMC/AmsterdamUMCdb/raw/master/img/logo_amds.png" alt="Logo" style="width: 128px;"/>

# AmsterdamUMCdb - Freely Accessible ICU Database
version 1.0.1 January 2020  
Copyright &copy; 2003-2020 Amsterdam UMC - Amsterdam Medical Data Science

# Datathon Jupyter notebooks
Notebooks for accessing AmsterdamUMCdb during  the [2nd Milan Critical Care Datathon](https://dat-icm-milan.com/).