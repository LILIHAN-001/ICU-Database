<img src="https://github.com/AmsterdamUMC/AmsterdamUMCdb/blob/master/img/logo_c4i_square.png?raw=1" alt="Logo C4I" width=128px><img src="https://github.com/AmsterdamUMC/AmsterdamUMCdb/blob/master/img/logo_amds.png?raw=1" alt="Logo AMDS" width=128px/>

# AmsterdamUMCdb - Freely Accessible ICU Database
version 1.0.2 March 2020  
Copyright &copy; 2003-2020 Amsterdam UMC - Amsterdam Medical Data Science

# Data folder
This folder is a placeholder for the AmsterdamUMCdb csv files. Extract the files into this folder so the Jupyter Notebooks can find them without manually changing the paths. However, you are free to choose another location, but make sure to modify the [`config.SAMPLE.ini`](../config.SAMPLE.ini) file in the root folder of this repository and save it as `config.ini`.
