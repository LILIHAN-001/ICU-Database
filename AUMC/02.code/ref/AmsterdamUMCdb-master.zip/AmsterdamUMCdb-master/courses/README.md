<img src="https://github.com/AmsterdamUMC/AmsterdamUMCdb/blob/master/img/logo_c4i_square.png?raw=1" alt="Logo C4I" width=128px><img src="https://github.com/AmsterdamUMC/AmsterdamUMCdb/blob/master/img/logo_amds.png?raw=1" alt="Logo AMDS" width=128px/>

# AmsterdamUMCdb - Freely Accessible ICU Database
version 1.0.2 March 2020  
Copyright &copy; 2003-2021 Amsterdam UMC - Amsterdam Medical Data Science

# Course Jupyter notebooks
This folder contains Getting Started guides (Jupyter notebooks) used in the introductory sessions to demonstrate connecting to Google BigQuery and Colab for accessing the data and example data exploration.