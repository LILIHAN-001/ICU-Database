"""amsterdamumcdb
Contains functions for simplifying data analysis and cleanup of the AmsterdamUMCdb database
"""

# For development:
# pip install -e ~/AmsterdamUMCdb/

#from PiPy repository (released version)
# pip install amsterdamumcdb
