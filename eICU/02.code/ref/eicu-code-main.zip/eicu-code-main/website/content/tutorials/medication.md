+++
date = "2015-09-01T19:34:46-04:00"
title = "medication"
linktitle = "medication"
weight = 10
toc = "false"

[menu]
  [menu.main]
    parent = "Tutorials"
    identifier = "medication notebook"
+++

# medication example notebook

Below is an embedded notebook which gives example usage of the medication table.
Source code for this and other notebooks can be found at the code repository:
https://github.com/MIT-LCP/eicu-code/tree/master/notebooks

<iframe src="https://nbviewer.jupyter.org/github/MIT-LCP/eicu-code/blob/master/notebooks/medication.ipynb" width="100%" height="800" scrolling="yes"></iframe>
